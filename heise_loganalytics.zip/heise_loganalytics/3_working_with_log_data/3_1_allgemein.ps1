<# 
1. Planen des PowerShell Scripts
    - TaskScheduler
    - Cron/Systemd
    - Pipelining Tool
    - Externe Software
2. LogImport und Analyse
3. Aufbereiten der Log-Daten
4. Weiterleiten der relevanten Informationen
    - API-Call
    - Mailversand
    - WebHooks
#>

