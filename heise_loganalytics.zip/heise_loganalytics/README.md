Log-Sammlung
https://github.com/logpai/loghub